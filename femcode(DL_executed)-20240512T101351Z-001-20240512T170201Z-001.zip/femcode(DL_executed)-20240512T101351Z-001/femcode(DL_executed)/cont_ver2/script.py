import os
for i in range(499):
  os.system(f"cp prop{i}.dat prop.dat")
  os.system("./main.e > shape")
  os.system(f"cp displacement displacement{i}")
#print(f"{i}this is running")
